public class Test {
    public static void main(String[] args) {
        Usuario usuario = new Usuario();
        try {
            // Establecer la primera contraseña (válida).
            usuario.setPassword("Abcdef1!");
            // Actualizar a una nueva contraseña válida.
            usuario.setPassword("Xyz123@#");
            // Actualizar a otra contraseña válida.
            usuario.setPassword("MnbvcZ9$");
            // Intentar establecer una contraseña que ya se usó anteriormente (debe lanzar excepción).
            usuario.setPassword("Abcdef1!");
        } catch (PasswordInvalidaException | PasswordRepetidaException e) {
            System.out.println("Error: " + e.getMessage());
        }
        // Mostrar el historial de contraseñas.
        usuario.mostrarHistorial();
    }
}
