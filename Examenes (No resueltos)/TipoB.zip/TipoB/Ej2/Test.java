public class Test {
    public static void main(String[] args) {
        try {
            // Crear instancias de Persona con datos válidos.
            Persona p1 = new Persona("Ana García", 25, "12345678A");
            Persona p2 = new Persona("Luis Martínez", 17, "87654321B");
            Persona p3 = new Persona("Carlos López", 45, "11223344C");
            // Mostrar datos y comprobación de mayoría de edad.
            System.out.println(p1);
            System.out.println(p2);
            System.out.println(p3);
            System.out.println();
            // Actualizar datos de p2 (por ejemplo, cambiar edad y DNI).
            p2.actualizarDatos("Luis Martínez", 18, "87654321B");  // Cambiamos la edad a 18
            System.out.println("Después de actualizar datos de p2:");
            System.out.println(p2);
            System.out.println();
            // Crear un registro de personas.
            RegistroPersonas registro = new RegistroPersonas();
            // Intentar agregar una persona con DNI duplicado (esto lanzará excepción).
            try {
                registro.agregarPersona(p1);
                registro.agregarPersona(p2);
                registro.agregarPersona(p3);
                Persona p4 = new Persona("Marta Ruiz", 30, "12345678A");  // DNI duplicado con p1
                registro.agregarPersona(p4);
            } catch (DniDuplicadoException e) {
                System.out.println("Error al agregar persona: " + e.getMessage());
            }
            // Buscar personas por nombre.
            registro.buscarPorNombre("Martí");
            // Listar todas las personas registradas.
            System.out.println();
            registro.listarPersonas();
        } catch (EdadInvalidaException | DniInvalidoException e) {
            System.out.println("Error en la creación de la persona: " + e.getMessage());
        }
    }
}

