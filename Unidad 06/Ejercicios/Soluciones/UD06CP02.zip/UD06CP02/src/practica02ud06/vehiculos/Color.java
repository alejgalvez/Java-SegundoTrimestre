package practica02ud06.vehiculos;

public enum Color {
    BLANCO, NEGRO, GRIS, ROJO, AZUL
}
