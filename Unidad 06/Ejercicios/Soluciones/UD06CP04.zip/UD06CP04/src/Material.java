public enum Material {
    ALGODON, CUERO, POLIESTER, LANA, SEDA
}
