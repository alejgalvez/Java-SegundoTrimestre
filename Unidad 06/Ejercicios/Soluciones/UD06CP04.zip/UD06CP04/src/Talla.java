public enum Talla {
    XS,S,M,L,XL,XXL
}
