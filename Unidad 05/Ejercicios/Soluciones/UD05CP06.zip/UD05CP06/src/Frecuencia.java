public enum Frecuencia {
    SEMANAL, MENSUAL, TRIMESTRAL, SEMESTRAL, ANUAL
}
