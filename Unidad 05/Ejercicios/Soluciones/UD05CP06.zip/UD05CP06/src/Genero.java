public enum Genero {
    FICCION, CIENCIA, NO_FICCION
}
