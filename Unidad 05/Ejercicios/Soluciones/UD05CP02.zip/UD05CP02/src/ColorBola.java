public enum ColorBola {
    BLANCA, NEGRA
}
