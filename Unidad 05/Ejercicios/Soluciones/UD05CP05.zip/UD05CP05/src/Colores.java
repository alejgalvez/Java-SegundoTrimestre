public enum Colores {
    BLANCO, NEGRO, ROJO, AZUL, GRIS
}
