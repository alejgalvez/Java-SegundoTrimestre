public enum Consumo {
    A,B,C,D,E,F
}
